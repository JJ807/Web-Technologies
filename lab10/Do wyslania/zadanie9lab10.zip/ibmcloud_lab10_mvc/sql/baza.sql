create table osoba ( imie char(20), nazwisko char(20), miejscowosc char(20) ) ;
insert into osoba ( imie, nazwisko, miejscowosc ) values ('Adam', 'Kowalski','Krakow');
insert into osoba ( imie, nazwisko, miejscowosc ) values ('Marek','Babacki','Zakopane') ;
insert into osoba ( imie, nazwisko, miejscowosc ) values ('Zofia','Cabacka','Warszawa') ;
insert into osoba ( imie, nazwisko, miejscowosc ) values ('Marta','Dadacka','Olsztyn') ;
insert into osoba ( imie, nazwisko, miejscowosc ) values ('Michal','Zawadzki','Katowice') ;