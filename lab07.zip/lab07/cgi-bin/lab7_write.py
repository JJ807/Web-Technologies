#!/usr/bin/env python3
import json
import cgi 
form = cgi.FieldStorage()

# pobranie zaznaczonej odpowiedzi
user_answer = form.getvalue("options")

# czytanie poprzednich wartosci
infile = open('/home/vcap/app/cgi-bin/data.json','r')
dane = json.load(infile)

# inkrementacja 
for tablica in dane.get("seasons", 0):
    for i in tablica:
        if i == user_answer:
            tablica[user_answer] = tablica.get(user_answer) + 1

# zapisanie do pliku
with open('/home/vcap/app/cgi-bin/data.json', 'w') as outfile:
    json.dump(dane, outfile)


# redirect
print ("Content-type: text/html \n\n")
print("""<!DOCTYPE HTML>
<html><head><meta http-equiv="refresh" content="0; url=http://ti-lab07-2k20.eu-gb.mybluemix.net/static/lab7/lab7.html"/>
<script type="text/javascript">window.location.href = "http://ti-lab07-2k20.eu-gb.mybluemix.net/static/lab7/lab7.html"</script>
</head><body></body></html>""")